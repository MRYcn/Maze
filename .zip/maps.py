import pygame

from straight import Straight
from start import Start
from end import End
from impasse import Impasse

#map loader and manager

class Map_Manager:
    def __init__(self,navigator):
        self.game=navigator.game

        self.level_st={1:8}

        self.navigator=navigator
        self.map_els=[]
        self.st=0
        self.moving=False
        self.press_pos=False
        
        self.straight2=Straight(self.game)
        self.straight2.loc=(700,255)
        self.straight2.ang=90
        self.map_els.append(self.straight2)
        
        self.straight3=Straight(self.game)
        self.straight3.loc=(800,255)
        self.straight3.ang=90
        self.map_els.append(self.straight3)
        
        self.impasse1=Impasse(self.game)
        self.impasse1.loc=(600,255)
        self.impasse1.ang=0
        self.map_els.append(self.impasse1)
        
        self.impasse2=Impasse(self.game)
        self.impasse2.loc=(900,255)
        self.impasse2.ang=180
        self.map_els.append(self.impasse2)
        
        self.start=Start(self.game)
        self.start.loc=(600,255)
        self.start.ang=0
        self.map_els.append(self.start)
        
        self.end=End(self.game)
        self.end.loc=(900,255)
        self.end.ang=0
        self.map_els.append(self.end)
    
    def update(self):
        if self.start.loc[0]==600 and not self.navigator.moving and self.navigator.press_pos:
            self.st=1
            self.navigator.moving=True
            self.game.beginning=False
        if self.st==1 and self.start.loc[0]>500:
            for el in self.map_els:
                el.loc=(el.loc[0]-10,el.loc[1])
            self.navigator.ang=0
        if self.st==1 and self.start.loc[0]==500 and self.navigator.moving:
            self.navigator.press_pos=False
            self.navigator.moving=False
        
        #2
        if self.start.loc[0]==500 and not self.navigator.moving and self.navigator.press_pos:
            self.st=2
            self.navigator.moving=True
        if self.st==2 and self.start.loc[0]>400:
            for el in self.map_els:
                el.loc=(el.loc[0]-10,el.loc[1])
            self.navigator.ang=0
        if self.st==2 and self.start.loc[0]==400 and self.navigator.moving:
            self.navigator.press_pos=False
            self.navigator.moving=False
        
        #3
        if self.start.loc[0]==400 and not self.navigator.moving and self.navigator.press_pos:
            self.st=3
            self.navigator.moving=True
        if self.st==3 and self.start.loc[0]>300:
            for el in self.map_els:
                el.loc=(el.loc[0]-10,el.loc[1])
            self.navigator.ang=0
        if self.st==3 and self.start.loc[0]==300 and self.navigator.moving:
            self.navigator.press_pos=False
            self.navigator.moving=False
    
    def display(self):
        for el in self.map_els:
            el.display()

    def get_level_num(self):
        return 1

    def level_to_st(self,level):
        return self.level_st[level]
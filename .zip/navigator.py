import pygame
import math

from maps import Map_Manager

#navigator image and manager

class Navigator:
    def __init__(self,game):
        self.img=pygame.image.load('res/pic/navigator.png')
        self.game=game
        self.RW=game.REF_WIDTH
        self.RH=game.REF_HEIGHT
        self.loc=(600,255)
        self.ang=90
        self.press_pos=False
        self.moving=False
        
        self.mm=Map_Manager(self)
        
    
    def update(self):
        self.mm.update()
        if self.game.beginning:
            self.update0()
            
        self.mm.display()
        
        self.game.blit_to_sc(self.img,self.loc,-90+self.ang)
            
    def update0(self):
        x,y=self.game.mouse_pos
        dx,dy=x-600*self.game.w/self.RW,255*self.game.h/self.RH-y
        if dx==0:
            if dy>0:
                ang=90
            else:
                ang=-90
        elif dx>0:
            ang=math.degrees(math.atan(dy/dx))
        else:
            ang=math.degrees(math.atan(dy/dx))+180
        self.ang=ang
